module.exports = {
  BOT_TOKEN: "ISI TOKEN",
  OWNER_ID: ["IDS"],
};