const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateMessageTag,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
    generateMessageID,
} = require('@whiskeysockets/baileys');
const fs = require("fs");
const P = require("pino");
const axios = require("axios");
const path = require("path");
const figlet = require("figlet");
const startTime = Date.now();

const premiumFile = path.resolve("./premium_users.js");
let premiumUsers = require("./premium_users.js");

function isPremium(userId) {
  return premiumUsers.includes(userId.toString());
}
const crypto = require("crypto");
const token = config.BOT_TOKEN;
const chalk = require("chalk");
const bot = new TelegramBot(token, { polling: true });
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const sessions = new Map();
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

const defaultSettings = {
  cooldown: 60, // detik
  groupOnly: false
};

if (!fs.existsSync('./settings.json')) {
  fs.writeFileSync('./settings.json', JSON.stringify(defaultSettings, null, 2));
}

let settings = JSON.parse(fs.readFileSync('./settings.json'));

const cooldowns = new Map();

function runtime() {
  const ms = Date.now() - startTime;
  const seconds = Math.floor(ms / 1000) % 60;
  const minutes = Math.floor(ms / (1000 * 60)) % 60;
  const hours = Math.floor(ms / (1000 * 60 * 60)) % 24;
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

function badge(userId) {
  return {
    premium: isPremium(userId) ? "✅" : "❌",
    supervip: isSupervip(userId) ? "✅" : "❌"
  };
}
//msg.key.id

function dateTime() {
  const now = new Date();
  const formatter = new Intl.DateTimeFormat("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });

  const parts = formatter.formatToParts(now);
  const get = (type) => parts.find(p => p.type === type).value;

  return `${get("day")}-${get("month")}-${get("year")} ${get("hour")}:${get("minute")}:${get("second")}`;
}

//definisi bot token dari file config.js
const { BOT_TOKEN } = require("./config.js");

function isDev(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

const GITHUB_TOKEN = "ghp_";  
const GITHUB_REPO = "Owners/Repo";
const MOD_FILE = "mods.json"; 
const RESELLER_FILE = "resellers.json";
const TOKEN_FILE = "tokens.json";
const OWNER_FILE = "owners.json";
const ADMIN_FILE = "admin.json";
const PT_FILE = "pt.json";
//BUAT KAYAK DICONTOH 

async function getGithubTokens() {
  try {
    const response = await axios.get(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${TOKEN_FILE}`,
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    const content = Buffer.from(response.data.content, "base64").toString();
    return {
      tokens: JSON.parse(content),
      sha: response.data.sha,
    };
  } catch (error) {
    console.error("Error getting GitHub tokens:", error);
    return null;
  }
}

async function updateGithubFile(newToken) {
  try {
    const data = await getGithubTokens();
    if (!data) return false;

    const { tokens, sha } = data;

    if (!tokens.includes(newToken)) {
      tokens.push(newToken);
    } else {
      return false;
    }

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${TOKEN_FILE}`,
      {
        message: "Update token list",
        content: Buffer.from(JSON.stringify(tokens, null, 2)).toString(
          "base64"
        ),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    return true;
  } catch (error) {
    console.error("Error updating GitHub file:", error);
    return false;
  }
}

async function deleteGithubToken(tokenToDelete) {
  try {
    const data = await getGithubTokens();
    if (!data) return false;

    const { tokens, sha } = data;
    const index = tokens.indexOf(tokenToDelete);

    if (index === -1) return false;

    tokens.splice(index, 1);

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${TOKEN_FILE}`,
      {
        message: "Delete token from list",
        content: Buffer.from(JSON.stringify(tokens, null, 2)).toString(
          "base64"
        ),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    return true;
  } catch (error) {
    console.error("Error deleting GitHub token:", error);
    return false;
  }
}

async function getGithubOwners() {
  try {
    const response = await axios.get(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${OWNER_FILE}`,
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    const content = Buffer.from(response.data.content, "base64").toString();
    return {
      owners: JSON.parse(content),
      sha: response.data.sha,
    };
  } catch (error) {
    console.error("Error getting GitHub owners:", error);
    return null;
  }
}

async function updateOwnersFile(newOwner) {
  try {
    const data = await getGithubOwners();
    if (!data) return false;

    const { owners, sha } = data;

    if (!owners.includes(newOwner)) {
      owners.push(newOwner);
    } else {
      return false;
    }

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${OWNER_FILE}`,
      {
        message: "Update owners list",
        content: Buffer.from(JSON.stringify(owners, null, 2)).toString(
          "base64"
        ),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );
    return true;
  } catch (error) {
    console.error("Error updating GitHub owner:", error);
    return false;
  }
}

async function deleteGithubOwners(ownerToDelete) {
  try {
    const data = await getGithubOwners();
    if (!data) return false;

    const { owners, sha } = data;
    const index = owners.indexOf(ownerToDelete);

    if (index === -1) return false;

    owners.splice(index, 1);

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${OWNER_FILE}`,
      {
        message: "Delete owners from list",
        content: Buffer.from(JSON.stringify(owners, null, 2)).toString(
          "base64"
        ),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    return true;
  } catch (error) {
    console.error("Error deleting GitHub owner:", error);
    return false;
  }
}

async function getGithubMods() {
  try {
    const response = await axios.get(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${MOD_FILE}`,
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    const content = Buffer.from(response.data.content, "base64").toString();
    return {
      mods: JSON.parse(content),
      sha: response.data.sha,
    };
  } catch (error) {
    console.error("Error getting GitHub mods:", error);
    return null;
  }
}

async function updateModsFile(newMods) {
  try {
    const data = await getGithubMods();
    if (!data) return false;

    const { mods, sha } = data;

    if (!mods.includes(newMods)) {
      mods.push(newMods);
    } else {
      return false;
    }

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${MOD_FILE}`,
      {
        message: "Update mods list",
        content: Buffer.from(JSON.stringify(mods, null, 2)).toString("base64"),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );
    return true;
  } catch (error) {
    console.error("Error updating GitHub file:", error);
    return false;
  }
}

async function deleteGithubMods(modToDelete) {
  try {
    const data = await getGithubMods();
    if (!data) return false;

    const { mods, sha } = data;
    const index = mods.indexOf(modToDelete);

    if (index === -1) return false;

    mods.splice(index, 1);

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${MOD_FILE}`,
      {
        message: "Delete mods from list",
        content: Buffer.from(JSON.stringify(mods, null, 2)).toString("base64"),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    return true;
  } catch (error) {
    console.error("Error deleting GitHub token:", error);
    return false;
  }
}

async function getGithubResellers() {
  try {
    const response = await axios.get(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${RESELLER_FILE}`,
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    const content = Buffer.from(response.data.content, "base64").toString();
    return {
      resellers: JSON.parse(content),
      sha: response.data.sha,
    };
  } catch (error) {
    console.error("Error getting GitHub tokens:", error);
    return null;
  }
}

async function deleteGithubResellers(resellerToDelete) {
  try {
    const data = await getGithubResellers();
    if (!data) return false;

    const { resellers, sha } = data;
    const index = resellers.indexOf(resellerToDelete);

    if (index === -1) return false;

    resellers.splice(index, 1);

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${RESELLER_FILE}`,
      {
        message: "Delete reseller from list",
        content: Buffer.from(JSON.stringify(resellers, null, 2)).toString(
          "base64"
        ),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    return true;
  } catch (error) {
    console.error("Error deleting GitHub token:", error);
    return false;
  }
}

async function updateGithubResellers(newResellers) {
  try {
    const data = await getGithubResellers();
    if (!data) return false;

    const { resellers, sha } = data;

    if (!resellers.includes(newResellers)) {
      resellers.push(newResellers);
    } else {
      return false;
    }

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${RESELLER_FILE}`,
      {
        message: "Update resellers list",
        content: Buffer.from(JSON.stringify(resellers, null, 2)).toString(
          "base64"
        ),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    return true;
  } catch (error) {
    console.error("Error updating GitHub file:", error);
    return false;
  }
}

async function getGithubAdmins() {
  try {
    const response = await axios.get(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${ADMIN_FILE}`,
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    const content = Buffer.from(response.data.content, "base64").toString();
    return {
      admins: JSON.parse(content),
      sha: response.data.sha,
    };
  } catch (error) {
    console.error("Error getting GitHub tokens:", error);
    return null;
  }
}

async function deleteGithubAdmins(adminToDelte) {
  try {
    const data = await getGithubAdmins();
    if (!data) return false;

    const { admins, sha } = data;
    const index = admins.indexOf(adminToDelte);

    if (index === -1) return false;

    admins.splice(index, 1);

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${ADMIN_FILE}`,
      {
        message: "Delete admin from list",
        content: Buffer.from(JSON.stringify(admins, null, 2)).toString(
          "base64"
        ),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    return true;
  } catch (error) {
    console.error("Error deleting GitHub token:", error);
    return false;
  }
}

async function updateGithubAdmins(newAdmin) {
  try {
    const data = await getGithubAdmins();
    if (!data) return false;

    const { admins, sha } = data;

    if (!admins.includes(newAdmin)) {
      admins.push(newAdmin);
    } else {
      return false;
    }

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${ADMIN_FILE}`,
      {
        message: "Update admin list",
        content: Buffer.from(JSON.stringify(admins, null, 2)).toString(
          "base64"
        ),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    return true;
  } catch (error) {
    console.error("Error updating GitHub file:", error);
    return false;
  }
}

async function getGithubPt() {
  try {
    const response = await axios.get(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${PT_FILE}`,
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    const content = Buffer.from(response.data.content, "base64").toString();
    return {
      Pt: JSON.parse(content),
      sha: response.data.sha,
    };
  } catch (error) {
    console.error("Error getting GitHub tokens:", error);
    return null;
  }
}

async function deleteGithubPt(adminToDelte) {
  try {
    const data = await getGithubPt();
    if (!data) return false;

    const { Pt, sha } = data;
    const index = Pt.indexOf(adminToDelte);

    if (index === -1) return false;

    Pt.splice(index, 1);

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${ADMIN_FILE}`,
      {
        message: "Delete admin from list",
        content: Buffer.from(JSON.stringify(Pt, null, 2)).toString(
          "base64"
        ),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    return true;
  } catch (error) {
    console.error("Error deleting GitHub token:", error);
    return false;
  }
}

async function updateGithubPt(newAdmin) {
  try {
    const data = await getGithubPt();
    if (!data) return false;

    const { Pt, sha } = data;

    if (!Pt.includes(newAdmin)) {
      Pt.push(newAdmin);
    } else {
      return false;
    }

    await axios.put(
      `https://api.github.com/repos/${GITHUB_REPO}/contents/${ADMIN_FILE}`,
      {
        message: "Update pt list",
        content: Buffer.from(JSON.stringify(Pt, null, 2)).toString(
          "base64"
        ),
        sha: sha,
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );

    return true;
  } catch (error) {
    console.error("Error updating GitHub file:", error);
    return false;
  }
}

async function isToken() {
  try {
    const token = await getGithubTokens();
    if (!token) return false;

    const { tokens } = token;

    if (!tokens.includes(BOT_TOKEN)) {
      return false;
    } else {
      return true;
    }
  } catch (error) {
    console.error("Terjadi kesalahan saat mengambil data:", error);
    return false;
  }
}

async function isOwner(msg) {
  try {
    const ownersData = await getGithubOwners();
    if (!ownersData) return false;

    const { owners } = ownersData;

    if (!owners.includes(String(msg.from.id))) {
      return false;
    } else {
      return true;
    }
  } catch (error) {
    console.error("Terjadi kesalahan saat mengambil data:", error);
    return false;
  }
}

async function isPt(msg) {
  try {
    const PtData = await getGithubPt();
    if (!PtData) return false;

    const { Pt } = PtData;

    if (!Pt.includes(String(msg.from.id))) {
      return false;
    } else {
      return true;
    }
  } catch (error) {
    console.error("Terjadi kesalahan saat mengambil data:", error);
    return false;
  }
}

async function isAdmin(msg) {
  try {
    const adminsData = await getGithubAdmins();
    if (!adminsData) return false;

    const { admins } = adminsData;

    if (!admins.includes(String(msg.from.id))) {
      return false;
    } else {
      return true;
    }
  } catch (error) {
    console.error("Terjadi kesalahan saat mengambil data:", error);
    return false;
  }
}

async function isMod(msg) {
  try {
    const modsData = await getGithubMods();
    if (!modsData) return false;

    const { mods, sha } = modsData;

    if (!mods.includes(String(msg.from.id))) {
      return false;
    } else {
      return true;
    }
  } catch (error) {
    console.error("Terjadi kesalahan saat mengambil data:", error);
    return false;
  }
}

async function isReseller(msg) {
  try {
    const resellersData = await getGithubResellers();
    if (!resellersData) return false;

    const { resellers, sha } = resellersData;

    if (!resellers.includes(String(msg.from.id))) {
      return false;
    } else {
      return true;
    }
  } catch (error) {
    console.error("Terjadi kesalahan saat mengambil data:", error);
    return false;
  }
}

//function group only
bot.on('message', (msg) => {
  const chatType = msg.chat.type;
if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg)) {
  return bot.sendMessage(msg.chat.id, '🚫 Bot ini hanya bisa digunakan di *grup*.', {
    parse_mode: 'Markdown'
  });
}

});

const allowedGroupIds = [
  -1002739427730,
  -1002509666831,
  -4708087819,
  5126860596,
];

function onlyGroup(msg) {
  if (msg.chat.type !== 'group' && msg.chat.type !== 'supergroup') {
    bot.sendMessage(msg.chat.id, '🚫 Command ini hanya bisa digunakan di grup.', {
      parse_mode: 'Markdown',
    });
    return false;
  }
  return true;
}

// Command /start
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;

  // Validasi: hanya untuk grup yang diizinkan
  if (!allowedGroupIds.includes(chatId)) {
    return bot.sendMessage(chatId, '🚫 Maaf, bot ini hanya bisa digunakan di grup tertentu saja.', {
      parse_mode: 'Markdown'
    });
  }

  try {
    // Menu awal
    await bot.sendPhoto(chatId, "https://files.catbox.moe/kdjzcj.jpg", {
      caption: 
`\`\`\`
データベース
オーナースクリプト: @xatanicvxii
バージョン : Database
使ってよかった !

以下のメニューを選択してください
\`\`\``,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "所有者", callback_data: "bug_menu" },
            { text: "再販業者", callback_data: "owner_menu" }
          ]
        ]
      }
    });

  } catch (err) {
    console.error("[/start] Error:", err);
  }
});

bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;

  // Validasi: hanya untuk grup yang diizinkan
  if (!allowedGroupIds.includes(chatId)) {
    return bot.answerCallbackQuery(callbackQuery.id, {
      text: '🚫 Bot ini hanya bisa digunakan di grup tertentu.',
      show_alert: true
    });
  }

  try {
    await bot.answerCallbackQuery(callbackQuery.id);

    // Menu Owner
    if (data === "bug_menu") {
      await bot.deleteMessage(chatId, callbackQuery.message.message_id);
      return bot.sendPhoto(chatId, "https://files.catbox.moe/kdjzcj.jpg", {
        caption: 
`\`\`\`
オーナーメニュー
◇ /addtoken
◇ /deltoken
◇ /addreseller
◇ /delreseller
◇ /addmod
◇ /delmod

オーナースクリプト: @xatanicvxii
\`\`\``,
        parse_mode: "MarkdownV2",
        reply_markup: {
          inline_keyboard: [[{ text: "「 BACK 」", callback_data: "start_menu" }]]
        }
      });
    }

    // Menu Reseller (khusus owner)
    if (data === "owner_menu") {
      if (!isOwner(callbackQuery)) {
        return bot.answerCallbackQuery(callbackQuery.id, {
          text: "🚫 Akses ditolak. Hanya untuk Owner.",
          show_alert: true
        });
      }

      await bot.deleteMessage(chatId, callbackQuery.message.message_id);
      return bot.sendPhoto(chatId, "https://files.catbox.moe/kdjzcj.jpg", {
        caption: 
`\`\`\`
再販業者アクセス
◇ /addtoken
◇ /deltoken
◇ /addreseller
◇ /delreseller
◇ /addmod
◇ /delmod

所有者: @xatanicvxii
\`\`\``,
        parse_mode: "MarkdownV2",
        reply_markup: {
          inline_keyboard: [[{ text: "「 BACK 」", callback_data: "start_menu" }]]
        }
      });
    }

    // Menu Awal (callback BACK)
    if (data === "start_menu") {
      await bot.deleteMessage(chatId, callbackQuery.message.message_id);
      return bot.sendPhoto(chatId, "https://files.catbox.moe/kdjzcj.jpg", {
        caption: 
`\`\`\`
データベース
オーナースクリプト: @xatanicvxii
バージョン : Database
使ってよかった !

以下のメニューを選択してください
\`\`\``,
        parse_mode: "MarkdownV2",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "所有者", callback_data: "bug_menu" },
              { text: "再販業者", callback_data: "owner_menu" }
            ]
          ]
        }
      });
    }

  } catch (err) {
    console.error("[callback_query] Error:", err);
  }
});

bot.on("message", (msg) => {
  const chatId = msg.chat.id;
});
const supervipFile = path.resolve("./supervip_users.js");
let supervipUsers = require("./supervip_users.js");

function isSupervip(userId) {
  const user = supervipUsers.find(u => u.id === userId.toString());
  if (!user) return false;
  const currentTime = Date.now();
  if (user.expiresAt < currentTime) {
    supervipUsers = supervipUsers.filter(u => u.id !== userId.toString());
    fs.writeFileSync(supervipFile, `const supervipUsers = ${JSON.stringify(supervipUsers, null, 2)};`);
    return false; 
  }
  return true; 
}

bot.onText(/\/addtoken(?:\s+(.+)|$)/, async (msg, match) => {
  if (!onlyGroup(msg)) return;

  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newToken = match[1] ? match[1].trim() : "";
  const thisOwner = await isOwner(msg);
  const thisMod = await isMod(msg);
  const thisReseller = await isReseller(msg);
  const thisPt = await isPt(msg);

  if (!thisOwner && !thisMod && !thisReseller && !thisPt) {
    return bot.sendMessage(chatId, `kamu bukan owner, mod, reseller atau pt!`, {
      parse_mode: "Markdown",
    });
  }

  if (!newToken) {
    return bot.sendMessage(
      chatId,
      ` Format tidak valid!
Contoh: /addtoken <token>`,
      { parse_mode: "Markdown" }
    );
  }

  try {
    const success = await updateGithubFile(newToken);

    if (success) {
      await bot.sendMessage(chatId, "Token berhasil ditambahkan", {
        parse_mode: "Markdown",
      });
    } else {
      await bot.sendMessage(chatId, "Token sudah ada atau terjadi kesalahan", {
        parse_mode: "Markdown",
      });
    }
  } catch (error) {
    console.error("Error adding token:", error);
    await bot.sendMessage(
      chatId,
      `Gagal menambahkan token
 Error: ${error.message}`,
      { parse_mode: "Markdown" }
    );
  }
});


bot.onText(/\/deltoken(?:\s+(.+)|$)/, async (msg, match) => {
  if (!onlyGroup(msg)) return;

  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const tokenToDelete = match[1] ? match[1].trim() : "";
  const thisOwner = await isOwner(msg);
  const thisMod = await isMod(msg);
  const thisReseller = await isReseller(msg);
  const thisPt = await isPt(msg);

  if (!thisOwner && !thisMod && !thisReseller && !thisPt) {
    return bot.sendMessage(chatId, `kamu bukan owner, mod, reseller atau pt!`, {
      parse_mode: "Markdown",
    });
  }

  if (!tokenToDelete) {
    return bot.sendMessage(
      chatId,
      `Format tidak valid!
Contoh: /deltoken <token>`,
      { parse_mode: "Markdown" }
    );
  }

  try {
    const success = await deleteGithubToken(tokenToDelete);

    if (success) {
      await bot.sendMessage(chatId, "Token berhasil dihapus", {
        parse_mode: "Markdown",
      });
    } else {
      await bot.sendMessage(
        chatId,
        "Token tidak ditemukan atau terjadi kesalahan",
        { parse_mode: "Markdown" }
      );
    }
  } catch (error) {
    console.error("Error deleting token:", error);
    await bot.sendMessage(
      chatId,
      `Gagal menghapus token
Error: ${error.message}`,
      { parse_mode: "Markdown" }
    );
  }
});


bot.onText(/\/addmod(?:\s+(.+)|$)/, async (msg, match) => {
  if (!onlyGroup(msg)) return;

  const chatId = msg.chat.id;
  const newMod = match[1] ? match[1].trim() : "";
  const thisOwner = await isOwner(msg);

  if (!thisOwner) {
    return bot.sendMessage(chatId, `kamu bukan owner!`, {
      parse_mode: "Markdown",
    });
  }

  if (!newMod) {
    return bot.sendMessage(
      chatId,
      ` Format tidak valid!
Contoh: /addmod <userId>`,
      { parse_mode: "Markdown" }
    );
  }

  try {
    const success = await updateModsFile(newMod);

    if (success) {
      await bot.sendMessage(chatId, "Mod berhasil ditambahkan", {
        parse_mode: "Markdown",
      });
    } else {
      await bot.sendMessage(chatId, "Mod sudah ada atau terjadi kesalahan", {
        parse_mode: "Markdown",
      });
    }
  } catch (error) {
    console.error("Error adding mod:", error);
    await bot.sendMessage(
      chatId,
      `Gagal menambahkan mod
 Error: ${error.message}`,
      { parse_mode: "Markdown" }
    );
  }
});


bot.onText(/\/delmod(?:\s+(.+)|$)/, async (msg, match) => {
  if (!onlyGroup(msg)) return;

  const chatId = msg.chat.id;
  const modToDelete = match[1] ? match[1].trim() : "";
  const thisOwner = await isOwner(msg);

  if (!thisOwner) {
    return bot.sendMessage(chatId, `kamu bukan owner!`, {
      parse_mode: "Markdown",
    });
  }

  if (!modToDelete) {
    return bot.sendMessage(
      chatId,
      `Format tidak valid!
Contoh: /delmod <userId>`,
      { parse_mode: "Markdown" }
    );
  }

  try {
    const success = await deleteGithubMods(modToDelete);

    if (success) {
      await bot.sendMessage(chatId, "Mod berhasil dihapus", {
        parse_mode: "Markdown",
      });
    } else {
      await bot.sendMessage(
        chatId,
        "Mod tidak ditemukan atau terjadi kesalahan",
        { parse_mode: "Markdown" }
      );
    }
  } catch (error) {
    console.error("Error deleting Mod:", error);
    await bot.sendMessage(
      chatId,
      `Gagal menghapus Mod
Error: ${error.message}`,
      { parse_mode: "Markdown" }
    );
  }
});


bot.onText(/\/addpt(?:\s+(.+)|$)/, async (msg, match) => {
  if (!onlyGroup(msg)) return;

  const chatId = msg.chat.id;
  const newPt = match[1] ? match[1].trim() : "";
  const thisOwner = await isOwner(msg);

  if (!thisOwner) {
    return bot.sendMessage(chatId, `kamu bukan owner!`, {
      parse_mode: "Markdown",
    });
  }

  if (!newPt) {
    return bot.sendMessage(
      chatId,
      ` Format tidak valid!
Contoh: /addPt <userId>`,
      { parse_mode: "Markdown" }
    );
  }

  try {
    const success = await updateGithubPt(newPt);

    if (success) {
      await bot.sendMessage(chatId, "Mod berhasil ditambahkan", {
        parse_mode: "Markdown",
      });
    } else {
      await bot.sendMessage(chatId, "Pt sudah ada atau terjadi kesalahan", {
        parse_mode: "Markdown",
      });
    }
  } catch (error) {
    console.error("Error adding Pt:", error);
    await bot.sendMessage(
      chatId,
      `Gagal menambahkan Pt
 Error: ${error.message}`,
      { parse_mode: "Markdown" }
    );
  }
});


bot.onText(/\/delpt(?:\s+(.+)|$)/, async (msg, match) => {
  if (!onlyGroup(msg)) return;

  const chatId = msg.chat.id;
  const ptToDelete = match[1] ? match[1].trim() : "";
  const thisOwner = await isOwner(msg);

  if (!thisOwner) {
    return bot.sendMessage(chatId, `kamu bukan owner!`, {
      parse_mode: "Markdown",
    });
  }

  if (!ptToDelete) {
    return bot.sendMessage(
      chatId,
      `Format tidak valid!
Contoh: /delpt <userId>`,
      { parse_mode: "Markdown" }
    );
  }

  try {
    const success = await deleteGithubPt(ptToDelete);

    if (success) {
      await bot.sendMessage(chatId, "Pt berhasil dihapus", {
        parse_mode: "Markdown",
      });
    } else {
      await bot.sendMessage(
        chatId,
        "Pt tidak ditemukan atau terjadi kesalahan",
        { parse_mode: "Markdown" }
      );
    }
  } catch (error) {
    console.error("Error deleting Pt:", error);
    await bot.sendMessage(
      chatId,
      `Gagal menghapus Pt
Error: ${error.message}`,
      { parse_mode: "Markdown" }
    );
  }
});


bot.onText(/\/addreseller(?:\s+(.+)|$)/, async (msg, match) => {
  if (!onlyGroup(msg)) return;

  const chatId = msg.chat.id;
  const newResellers = match[1] ? match[1].trim() : "";
  const thisOwner = await isOwner(msg);
  const thisMod = await isMod(msg);
  const thisPt = await isPt(msg);

  if (!thisOwner && !thisMod && !isPt(msg)) {
    return bot.sendMessage(chatId, `kamu bukan owner, mod, ataupun pt!`, {
      parse_mode: "Markdown",
    });
  }

  if (!newResellers) {
    return bot.sendMessage(
      chatId,
      ` Format tidak valid!
Contoh: /addreseller <userId>`,
      { parse_mode: "Markdown" }
    );
  }

  try {
    const success = await updateGithubResellers(newResellers);

    if (success) {
      await bot.sendMessage(chatId, "reseller berhasil ditambahkan", {
        parse_mode: "Markdown",
      });
    } else {
      await bot.sendMessage(
        chatId,
        "reseller sudah ada atau terjadi kesalahan",
        { parse_mode: "Markdown" }
      );
    }
  } catch (error) {
    console.error("Error adding reseller:", error);
    await bot.sendMessage(
      chatId,
      `Gagal menambahkan reseller
 Error: ${error.message}`,
      { parse_mode: "Markdown" }
    );
  }
});


bot.onText(/\/delreseller(?:\s+(.+)|$)/, async (msg, match) => {
  if (!onlyGroup(msg)) return;

  const chatId = msg.chat.id;
  const resellerToDelete = match[1] ? match[1].trim() : "";
  const thisOwner = await isOwner(msg);
  const thisMod = await isMod(msg);
  const thisPt = await isPt(msg);

  if (!thisOwner && !thisMod && !isPt(msg)) {
    return bot.sendMessage(chatId, `kamu bukan owner, mod, ataupun pt!`, {
      parse_mode: "Markdown",
    });
  }

  if (!resellerToDelete) {
    return bot.sendMessage(
      chatId,
      `Format tidak valid!
Contoh: /delreseller <userId>`,
      { parse_mode: "Markdown" }
    );
  }

  try {
    const success = await deleteGithubResellers(resellerToDelete);

    if (success) {
      await bot.sendMessage(chatId, "reseller berhasil dihapus", {
        parse_mode: "Markdown",
      });
    } else {
      await bot.sendMessage(
        chatId,
        "reseller tidak ditemukan atau terjadi kesalahan",
        { parse_mode: "Markdown" }
      );
    }
  } catch (error) {
    console.error("Error deleting reseller:", error);
    await bot.sendMessage(
      chatId,
      `Gagal menghapus reseller
Error: ${error.message}`,
      { parse_mode: "Markdown" }
    );
  }
});


bot.onText(/\/addowner(?:\s+(.+)|$)/, async (msg, match) => {
  if (!onlyGroup(msg)) return;

  const chatId = msg.chat.id;
  const newOwner = match[1] ? match[1].trim() : "";
  const thisOwner = await isOwner(msg);

  if (!thisOwner) {
    return bot.sendMessage(
      chatId,
      `
kamu bukan Developer!`,
      { parse_mode: "Markdown" }
    );
  }

  if (!newOwner) {
    return bot.sendMessage(
      chatId,
      ` Format tidak valid!
Contoh: /addowner <userId>`,
      { parse_mode: "Markdown" }
    );
  }

  try {
    const success = await updateOwnersFile(newOwner);

    if (success) {
      await bot.sendMessage(chatId, "Owner berhasil ditambahkan", {
        parse_mode: "Markdown",
      });
    } else {
      await bot.sendMessage(chatId, "Owner sudah ada", {
        parse_mode: "Markdown",
      });
    }
  } catch (error) {
    console.error("Error adding Owner:", error);
    await bot.sendMessage(
      chatId,
      `Gagal menambahkan Owner
 Error: ${error.message}`,
      { parse_mode: "Markdown" }
    );
  }
});


bot.onText(/\/delowner(?:\s+(.+)|$)/, async (msg, match) => {
  if (!onlyGroup(msg)) return;

  const chatId = msg.chat.id;
  const ownerToDelete = match[1] ? match[1].trim() : "";
  const thisOwner = await isOwner(msg);

  if (!thisOwner) {
    return bot.sendMessage(chatId, `kamu bukan Developer!`, {
      parse_mode: "Markdown",
    });
  }

  if (!ownerToDelete) {
    return bot.sendMessage(
      chatId,
      `Format tidak valid!
Contoh: /delowner <userId>`,
      { parse_mode: "Markdown" }
    );
  }

  try {
    const success = await deleteGithubOwners(ownerToDelete);

    if (success) {
      await bot.sendMessage(chatId, "Owner berhasil dihapus", {
        parse_mode: "Markdown",
      });
    } else {
      await bot.sendMessage(
        chatId,
        "Owner tidak ditemukan atau terjadi kesalahan",
        { parse_mode: "Markdown" }
      );
    }
  } catch (error) {
    console.error("Error deleting Owner:", error);
    await bot.sendMessage(
      chatId,
      `Gagal menghapus Owner
Error: ${error.message}`,
      { parse_mode: "Markdown" }
    );
  }
});

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

(async () => {
const validateToken = await isToken();
/*if (!validateToken) {
console.log(chalk.bold.red("TOKEN INVALID!\nSILAHKAN DAFTARKAN TOKEN ANDA!!"));
process.exit();
}*/
    console.clear();
    console.log(chalk.bold.red("\nTREDICT X ANGEL"));
    console.log(chalk.bold.white("XATANICAL"));
    console.log(chalk.bold.white("VERSION: 5.0"));
    console.log(chalk.bold.white("ACCESS: ") + chalk.bold.green("YES"));
    console.log(chalk.bold.white("STATUS: ") + chalk.bold.green("ONLINE\n\n"));
    console.log(chalk.bold.yellow("SCRIPT MEMILIKI DATABASE, JIKA DISHARE SECARA FREE DIPASTIKAN BACKDOOR YANG TIDAK AMAN DIGUNAKAN!, BUY AKSES @xatanicvxii"));
})()